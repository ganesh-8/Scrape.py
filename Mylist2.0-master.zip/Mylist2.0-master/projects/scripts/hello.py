
pri nt("hello world")
